package testviewtest.buildappswithpaulo.com.customtextviewtest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.jar.Attributes;

public class MainActivity extends AppCompatActivity  {
    private ArrayAdapter<String> arrayAdapter;
    private ArrayList<String> todoItems;
    private ListView listView;
    private EditText editText;
    private TextView textView;

    private Button addButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);


//        CustomTextView customTextView = new CustomTextView(this, null);
//        customTextView.setText("Hello World");
//        setContentView(customTextView);

        Square square = new Square(this, null);
        setContentView(square);


//        addButton = findViewById(R.id.addButton);
//        editText = findViewById(R.id.editText);
//
//        listView = findViewById(R.id.listview);
//        todoItems = new ArrayList<>();
//
//        arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, todoItems);
//
//        listView.setAdapter(arrayAdapter);
//
//        addButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                String todoString = editText.getText().toString().trim();
//                addItem(todoString);
//            }
//        });
//    }
//
//    private void addItem(String todoString) {
//        todoItems.add(todoString);
//        arrayAdapter.notifyDataSetChanged();
//    }
    }
}
