package testviewtest.buildappswithpaulo.com.customtextviewtest;

import android.content.Context;
import android.support.annotation.NonNull;
import android.widget.ArrayAdapter;

/**
 * Created by paulodichone on 11/10/17.
 */

public class AdapterCustom extends ArrayAdapter<String> {

    public AdapterCustom(@NonNull Context context, int resource) {
        super(context, resource);
    }


}
