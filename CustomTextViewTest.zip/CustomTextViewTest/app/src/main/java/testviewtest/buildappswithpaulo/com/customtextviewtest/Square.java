package testviewtest.buildappswithpaulo.com.customtextviewtest;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;


/**
 * Created by paulodichone on 11/10/17.
 */

public class Square extends View {
    private Paint colorBrush;

    public Square(Context context) {
        super(context);
        init();
    }

    public Square(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public Square(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    public Square(Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init();
    }

    private void init() {

        colorBrush = new Paint(Paint.ANTI_ALIAS_FLAG); //Anti-Alias-Flag - in computer graphics) a technique used to add greater realism to a digital image by smoothing jagged edges on curved lines and diagonals.
        colorBrush.setColor(Color.parseColor("green"));

    }

    @Override
    protected void onDraw(Canvas canvas) {


        canvas.drawCircle(getMeasuredWidth() / 2, getMeasuredHeight() / 2, 89f, colorBrush);

        RectF rectF = new RectF(getMeasuredHeight() + 45, getMeasuredWidth() / 3, 12f, 34f);
        canvas.drawOval(rectF, colorBrush);

        canvas.drawText("What's Up", getMeasuredWidth()/3, getMeasuredHeight()/2, colorBrush);
        canvas.save();
        super.onDraw(canvas);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int userFinger = event.findPointerIndex(MotionEvent.TOOL_TYPE_FINGER);

        Log.d("Touched", String.valueOf(userFinger));
        return true;

    }
}
