package sensortester.buildappswithpaulo.com.sensortester;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;

import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.emredavarci.circleprogressbar.CircleProgressBar;
import com.github.florent37.viewanimator.AnimationListener;
import com.github.florent37.viewanimator.ViewAnimator;

import static java.lang.String.format;


public class MainActivity extends AppCompatActivity {
    TextView textView;
    ImageView imageView;
    private SensorManager mSensorManager;
    private Sensor mLight;
    private Button start;
    private ViewAnimator viewAnimator;
    private Prefs prefs;
    private TextView breathsTxt, timeTxt,
            sessionTxt;


    @SuppressLint("DefaultLocale")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        start = findViewById(R.id.startButton);


        final CircleProgressBar progressBar = (CircleProgressBar) findViewById(R.id.progressBar);


        new CountDownTimer(25 * 1000, 1000 ) {
            @Override
            public void onTick(long l) {
                progressBar.setProgress(l/ 1000);
                progressBar.setText( String.valueOf(l/ 1000));

            }

            @Override
            public void onFinish() {

            }
        }.start();


        prefs = new Prefs(this);

        breathsTxt = findViewById(R.id.breathesTakenTxt);
        timeTxt = findViewById(R.id.lastBreathTxt);
        sessionTxt = findViewById(R.id.todayMinutesTxt);


        imageView = findViewById(R.id.imageView);
        textView = findViewById(R.id.guideText);
        textView.setTextColor(Color.WHITE);
        textView.setText("Breathe");

        startIntroAnimation();

        // Log.d("Session", String.valueOf(prefs.getSessions()));
        sessionTxt.setText(format("%s min today", String.valueOf(prefs.getSessions())));
        breathsTxt.setText(String.format("Breaths: %d", prefs.getBreaths()));
        timeTxt.setText(prefs.getDate());


        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startAnimation();
            }
        });


//        com.github.florent37.viewanimator.ViewAnimator
//                .animate(textView)
//                .custom(new AnimationListener.Update<TextView>() {
//                    @Override public void update(TextView view, float value) {
//                        view.setText(String.format("%.02f",value));
//                    }
//                }, 0, 1)
//                .start();


    }

    public void startIntroAnimation() {
        ViewAnimator.animate(textView)
                .scale(0, 1)
                .duration(1500)
                .onStart(new AnimationListener.Start() {
                    @Override
                    public void onStart() {
                        textView.setText("Breathe");
                    }
                })
                .onStop(new AnimationListener.Stop() {
                    @Override
                    public void onStop() {
//                        ViewAnimator.animate(textView)
//                                .fadeOut()
//                                .start();
                    }
                })
                .start();
    }

    public void startAnimation() {

        ViewAnimator
                .animate(imageView)
                // .translationY(400, 0)
                .alpha(0, 1)
                .onStart(new AnimationListener.Start() {
                    @Override
                    public void onStart() {
                        textView.setText("Inhale... and exhale!");
                    }
                })
                .decelerate()
                .duration(1000)
                .thenAnimate(imageView)
                .scale(0.02f, 1.5f, 0.02f)
                .rotation(360)
                .repeatCount(2)
                .accelerate()
                .duration(5000)
                .onStop(new AnimationListener.Stop() {
                    @Override
                    public void onStop() {
                        textView.setText("Good Job!");
                        imageView.setScaleX(1.0f);
                        imageView.setScaleY(1.0f);
                        prefs.setSessions(prefs.getSessions() + 1);
                        prefs.setBreaths(prefs.getBreaths() + 1);
                        prefs.setDate(System.currentTimeMillis());
                        Log.d("Session", String.valueOf(prefs.getSessions()));

                        textView.setText("Well done.");

                        //refresh activity

                         new CountDownTimer(2000, 1000) {
                            @Override
                            public void onTick(long l) {

                            }

                            @Override
                            public void onFinish() {
                                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                                finish();

                            }
                        }.start();



                    }
                })
                .start();

    }


}
