package sensortester.buildappswithpaulo.com.sensortester;

import android.app.Activity;
import android.content.SharedPreferences;

import java.util.Calendar;

/**
 * Created by paulodichone on 11/22/17.
 */

public class Prefs {

    private SharedPreferences preferences;

    public Prefs(Activity activity) {
        preferences = activity.getPreferences(Activity.MODE_PRIVATE);

    }

    public String getDate() {
        long secondsDate = preferences
                .getLong("seconds", 0);
        String amOrPm;


        Calendar cl = Calendar.getInstance();
        int a = cl.get(Calendar.AM_PM);
        if (a == Calendar.AM)
            amOrPm = "AM";
        else
            amOrPm = "PM";


        cl.setTimeInMillis(secondsDate);
        //here your time in miliseconds
        // String date = "" + cl.get(Calendar.DAY_OF_MONTH) + ":" + cl.get(Calendar.MONTH) + ":" + cl.get(Calendar.YEAR);
        String time = ""
                + cl.get(Calendar.HOUR_OF_DAY) + ":" + cl.get(Calendar.MINUTE) + " " + amOrPm;


        return time;


    }

    public void setDate(long milliseconds) {
        preferences.edit().putLong("seconds", milliseconds).apply();
    }

    public int getSessions() {
        return preferences.getInt("session", 0);
    }

    public void setSessions(int session) {
        preferences.edit().putInt("session", session).apply();

    }

    public int getBreaths() {
        return preferences.getInt("breaths", 0);
    }

    public void setBreaths(int breaths) {
        preferences.edit().
                putInt("breaths", breaths).
                apply();
    }

}
